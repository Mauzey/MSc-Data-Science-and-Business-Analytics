#' The questionnaire data
#'
#' The questionnaire data shows the responses given by the a group of Plymouth students
#' to 19 questions.
#' The data set contains one unusual answer.
#' An additional error (changing one age from 21 to 12) has been introduced for illustrative purposes
#'
#'
#' @format A data.frame with 18 rows and 19 columns, containing responses to the following questions:
#' \describe{
#'  \item{Height}{What is your height in cms? (cms)}
#'  \item{Age}{What is your age as a decimal? (years, as decimal)}
#'  \item{Sex}{What is your sex? (Female or Male)}
#'  \item{BirthPlace}{Where were you born?}
#'  \item{SiblingNo}{How many siblings (brothers and sisters, including step-brothers and step-sisters) do you have?}
#'  \item{EatMeat}{Do you eat mean? (Yes or No)}
#'  \item{DrinkCoffee}{Do you drink coffee? (Yes or No)}
#'  \item{LikeBeer}{Do you like beer? (Yes or No)}
#'  \item{Sports}{Do you play sports? (Yes or No)}
#'  \item{Driver}{Do you have a full driving licence? (Yes or No)}
#'  \item{LeftHanded}{Are you left-handed? (Yes or No)}
#'  \item{Abroad}{Did you go abroad on holiday this year? (Yes or No)}
#'  \item{Sleep}{How much sleep do you think that you had last night (in hours)? (hours)}
#'  \item{Rent}{How much do you pay each calendar month for your term time accommodation (in pounds)? (pounds)}
#'  \item{Happy_accommodation}{Are you happy with the quality of your term time accommodation (Yes or No)}
#'  \item{Distance}{How far is your term time accommodation from the Babbage Building (to the nearest 0.1 of a mile, best guess)? (miles, in tenths)}
#'  \item{Travel_time}{How long does it take you to travel from your term time accommodation to the Babbage Building (in minutes, best guess)? (minutes)}
#'  \item{Mode_of_transport}{What is your usual way of travelling to the University (if you use more than one means of transport, please state the one which takes the most time)?}
#'  \item{Safe}{Do you feel safe returning to your term time accommodation at night? (Yes or No)}
#' }
#'
#' @examples
#' with(MATH513_Questionnaire_Data, mean(Height))
#' with(MATH513_Questionnaire_Data, sd(Age))
#' with(MATH513_Questionnaire_Data, table(SiblingsNo))
#' with(MATH513_Questionnaire_Data, table(Mode_of_transport))
#' with(MATH513_Questionnaire_Data, table(DrinkCoffee, LikeBeer))
#' with(MATH513_Questionnaire_Data, plot(Distance, Travel_time, log = "xy))
#'
#' @source Data provided electronically by a group of Plymouth students.
"qa_data"
